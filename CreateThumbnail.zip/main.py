from google.cloud import storage, pubsub_v1
from PIL import Image
import io
import os
import tempfile
import json

storage_client = storage.Client()
publisher = pubsub_v1.PublisherClient()

def resize_image(data, context):
    """Background Cloud Function to resize an image on GCS object finalize.

    Expects environment variables:
      DESTINATION_BUCKET: destination bucket name
      PUBSUB_TOPIC: optional pubsub topic name (short name)
    """
    bucket_name = data.get('bucket')
    name = data.get('name')
    if not bucket_name or not name:
        raise ValueError('Missing bucket or name in event')

    dest_bucket_name = os.environ.get('DESTINATION_BUCKET')
    pubsub_topic = os.environ.get('PUBSUB_TOPIC')

    # Download source
    bucket = storage_client.bucket(bucket_name)
    blob = bucket.blob(name)

    with tempfile.NamedTemporaryFile() as tmp:
        blob.download_to_filename(tmp.name)
        img = Image.open(tmp.name)
        img.thumbnail((800, 800))
        out_buf = io.BytesIO()
        img.convert('RGB').save(out_buf, format='JPEG')
        out_buf.seek(0)

        # Upload to destination
        if not dest_bucket_name:
            raise ValueError('DESTINATION_BUCKET environment variable not set')
        dest_bucket = storage_client.bucket(dest_bucket_name)
        dest_blob = dest_bucket.blob(f'resized-{name}')
        dest_blob.upload_from_file(out_buf, content_type='image/jpeg')

    # Publish notification if requested
    if pubsub_topic:
        project = os.environ.get('GCP_PROJECT') or os.environ.get('GOOGLE_CLOUD_PROJECT') or os.environ.get('PROJECT_ID')
        if project:
            topic_path = publisher.topic_path(project, pubsub_topic)
            message_json = json.dumps({'source': name, 'destination': f'resized-{name}', 'bucket': dest_bucket_name})
            publisher.publish(topic_path, message_json.encode('utf-8'))

    return 'resized'
